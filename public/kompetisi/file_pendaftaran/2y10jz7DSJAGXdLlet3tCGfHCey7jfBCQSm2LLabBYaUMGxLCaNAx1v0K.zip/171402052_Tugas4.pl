byCar(auckland,hamilton).
byCar(hamilton,ragland).
byCar(valmont,saarbruecken).
byCar(valmont,metz).

byTrain(metz,frankfurt).
byTrain(saarbruecken,frankfurt).
byTrain(metz,paris).
byTrain(saarbruecken,paris).

byPlane(frankfurt,bangkok).
byPlane(frankfurt,singapore).
byPlane(paris,losAngeles).
byPlane(bangkok,auckland).
byPlane(singapore,auckland).
byPlane(losAngeles,auckland).

% Rules

% Rules untuk pengecekan kendaraan yang tersedia berdasarkan fact
travel(X,Y,Z) :- byCar(X,Y),Z = 'car'.
travel(X,Y,Z) :- byTrain(X,Y),Z = 'train'.
travel(X,Y,Z) :- byPlane(X,Y),Z = 'plane'.

% Rules untuk memastikan apakah travel dari kota X ke kota Y tersedia
travel(X,Y) :- byCar(X,Y).
travel(X,Y) :- byTrain(X,Y).
travel(X,Y) :- byPlane(X,Y).

% Rules untuk mencari apakah travel dr kota X ke kota Y ada, jika ada akan print kota X = kendaraan apa => kota Y
path(X,Y) :- travel(X,Y),write('['),write(X),write(']'),travel(X,Y,T),write('='),write(T),write('=>'),write('['),write(Y),write(']').
% Rules untuk mengecek apakah travel dr kota X ke kota Z tersedia, jika tersedia maka Z akan di masukkan ke rekursif
path(X,Y) :- travel(X,Z),travel(X,Z,T),write('['),write(X),write(']'),write('='),write(T),write('=>'),path(Z,Y).